from airflow.plugins_manager import AirflowPlugin
from flask import Blueprint
from custom_config_plugin.models import AppSetting

custom_config_bp = Blueprint(
    "custom_config_bp",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/static/custom_config_plugin",
)


class CustomConfigPlugin(AirflowPlugin):
    name = "custom_config_plugin"

    flask_appbuilder_views = [
        {
            "name": "App Settings",
            "category": "Custom Config",
            "view": "custom_config_plugin.views.AppSettingView",  # dùng string path
        }
    ]

    blueprints = [custom_config_bp]

    menu_links = [
        {
            "name": "Custom Config",
            "href": "/app/custom_config_plugin/appsettingview/list/",
            "category": "Custom Plugins",
        }
    ]

    models = [AppSetting]
