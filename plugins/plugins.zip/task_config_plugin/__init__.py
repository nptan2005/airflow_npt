from airflow.plugins_manager import AirflowPlugin
from flask import Blueprint
from task_config_plugin.models import TaskDefinition

# Create a Flask Blueprint (optional)
task_config_bp = Blueprint(
    "task_config_bp",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/static/task_config_plugin",
)


class TaskConfigPlugin(AirflowPlugin):
    name = "task_config_plugin"

    flask_appbuilder_views = [
        {
            "name": "Task Definitions",
            "category": "Task Configuration",
            "view": "task_config_plugin.views.TaskDefinitionView",  # <-- dùng string path
        }
    ]

    blueprints = [task_config_bp]
    models = [TaskDefinition]
