class ExportConstant: 

    DEFAULT = "DEFAULT"
    RPT_EXCEL_FILE_TYPE = "xlsx"
    RPT_EXCEL_FILE_TYPE_OLD = "xls"
    RPT_TEXT_FILE_TYPE = "txt"
    RPT_CSV_FILE_TYPE = "csv"
    RPT_JSON_FILE_TYPE = "json"