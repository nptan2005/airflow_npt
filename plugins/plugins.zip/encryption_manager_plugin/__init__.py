from airflow.plugins_manager import AirflowPlugin
from flask import Blueprint
from encryption_manager_plugin.models import EncryptedDataRef

# Create a Flask Blueprint for the plugin
encryption_manager_bp = Blueprint(
    "encryption_manager_bp",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/static/encryption_manager_plugin",
)


class EncryptionManagerPlugin(AirflowPlugin):
    name = "encryption_manager_plugin"

    flask_appbuilder_views = [
        {
            "name": "Encrypt New Data",
            "category": "Encryption Manager",
            "view": "encryption_manager_plugin.views.EncryptDataView",  # dùng string path
        },
        {
            "name": "View Encrypted Refs",
            "category": "Encryption Manager",
            "view": "encryption_manager_plugin.views.EncryptedDataRefView",  # dùng string path
        },
    ]

    blueprints = [encryption_manager_bp]
    models = [EncryptedDataRef]
