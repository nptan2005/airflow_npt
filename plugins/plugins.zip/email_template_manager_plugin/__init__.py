from airflow.plugins_manager import AirflowPlugin
from flask import Blueprint
from email_template_manager_plugin.models import DBEmailTemplate

# Tạo Flask Blueprint (tùy chọn)
email_template_manager_bp = Blueprint(
    "email_template_manager_bp",
    __name__,
    template_folder="templates",
    static_folder="static",
    static_url_path="/static/email_template_manager_plugin",
)


class EmailTemplateManagerPlugin(AirflowPlugin):
    name = "email_template_manager_plugin"

    flask_appbuilder_views = [
        {
            "name": "Email Templates",
            "category": "Email Management",
            "view": "email_template_manager_plugin.views.DBEmailTemplateView",  # dùng string path
        }
    ]

    blueprints = [email_template_manager_bp]
    models = [DBEmailTemplate]
